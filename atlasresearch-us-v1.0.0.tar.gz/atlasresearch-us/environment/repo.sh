#!/bin/bash

############################################################################
# Copyright 2020, Anteris Technologies LLC d/b/a Insipher.
# All rights reserved.
# info@insipher.com
# 
# NOTICE:  All information contained herein is, and remains
# the property of Anteris Technologies LLC d/b/a Insipher (“Insipher”).
# The intellectual and technical concepts contained herein are proprietary
# to Insipher and may be covered by U.S. and foreign patents or
# patent applications, trade secret, or copyright. Dissemination of
# this information or reproduction of this material is strictly
# forbidden unless prior written permission is obtained from Insipher.
#

export DISTRIBUTION_NAMESPACE=insipher
export DISTRIBUTION_REPO=940093668739.dkr.ecr.us-east-2.amazonaws.com/$DISTRIBUTION_NAMESPACE
export PROFILE=atlasresearch-us

aws ecr get-login-password --profile $PROFILE \
        --region us-east-1 | docker login \
        --username AWS \
        --password-stdin 940093668739.dkr.ecr.us-east-1.amazonaws.com

