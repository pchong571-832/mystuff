#!/bin/bash

############################################################################
# Copyright 2020, Anteris Technologies LLC d/b/a Insipher.
# All rights reserved.
# info@insipher.com
# 
# NOTICE:  All information contained herein is, and remains
# the property of Anteris Technologies LLC d/b/a Insipher (“Insipher”).
# The intellectual and technical concepts contained herein are proprietary
# to Insipher and may be covered by U.S. and foreign patents or
# patent applications, trade secret, or copyright. Dissemination of
# this information or reproduction of this material is strictly
# forbidden unless prior written permission is obtained from Insipher.
#

eksctl create cluster -f $PWD/environment/cluster-config.yaml

eksctl create iamidentitymapping --cluster atlasresearch-us --arn arn:aws:iam::587393751500:user/jenkins --group system:masters --username jenkins

eksctl create iamidentitymapping --cluster atlasresearch-us --arn arn:aws:iam::587393751500:user/dpinkston@datafactory.us --group system:masters --username dpinkston@datafactory.us

eksctl create iamidentitymapping --cluster atlasresearch-us --arn arn:aws:iam::587393751500:user/devin.pinkston@insipher.com --group system:masters --username devin.pinkston@insipher.com

eksctl create iamidentitymapping --cluster atlasresearch-us --arn arn:aws:iam::587393751500:user/david.cunningham@insipher.com --group system:masters --username david.cunningham@insipher.com
