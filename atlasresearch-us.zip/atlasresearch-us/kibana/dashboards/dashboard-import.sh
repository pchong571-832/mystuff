#!/bin/bash

############################################################################
# Copyright 2020, Anteris Technologies LLC d/b/a Insipher.
# All rights reserved.
# info@insipher.com
# 
# NOTICE:  All information contained herein is, and remains
# the property of Anteris Technologies LLC d/b/a Insipher (“Insipher”).
# The intellectual and technical concepts contained herein are proprietary
# to Insipher and may be covered by U.S. and foreign patents or
# patent applications, trade secret, or copyright. Dissemination of
# this information or reproduction of this material is strictly
# forbidden unless prior written permission is obtained from Insipher.
#

hostname="localhost:5601"

dashboardExport() {
  curl -X POST "$hostname/api/saved_objects/_import" -H "kbn-xsrf: true" --form file=@dashboards/kibana-dashboard.ndjson
}

#until $(curl --output /dev/null --silent --head --fail $hostname); do
#    printf 'waiting for kibana to come online'
#    sleep 5
#done
#sleep 10
if curl -X POST "$hostname/api/saved_objects/_import" -H "kbn-xsrf: true" --form file=@dashboards/kibana-dashboard.ndjson; then
    exit 0
else
    printf 'Curl failed with error code "%d" (check the manual)\n' "$?" >&2
    exit 0
fi
