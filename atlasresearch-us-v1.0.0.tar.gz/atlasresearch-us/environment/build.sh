#!/bin/bash

############################################################################
# Copyright 2020, Anteris Technologies LLC d/b/a Insipher.
# All rights reserved.
# info@insipher.com
# 
# NOTICE:  All information contained herein is, and remains
# the property of Anteris Technologies LLC d/b/a Insipher (“Insipher”).
# The intellectual and technical concepts contained herein are proprietary
# to Insipher and may be covered by U.S. and foreign patents or
# patent applications, trade secret, or copyright. Dissemination of
# this information or reproduction of this material is strictly
# forbidden unless prior written permission is obtained from Insipher.
#

# setup repositories
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/algorithm-api || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/dataset-api || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/elasticsearch || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/iam-api || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/insight-api || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/jenkins || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/keycloak || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/kibana || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/mlflow || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/nifi || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/pipeline-api || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/presto || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/workshop || true
aws ecr create-repository --profile $PROFILE --repository-name $DISTRIBUTION_NAMESPACE/algorithms || true