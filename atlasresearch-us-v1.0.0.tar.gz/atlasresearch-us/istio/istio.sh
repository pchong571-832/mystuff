#!/bin/sh

############################################################################
# Copyright 2020, Anteris Technologies LLC d/b/a Insipher.
# All rights reserved.
# info@insipher.com
# 
# NOTICE:  All information contained herein is, and remains
# the property of Anteris Technologies LLC d/b/a Insipher (“Insipher”).
# The intellectual and technical concepts contained herein are proprietary
# to Insipher and may be covered by U.S. and foreign patents or
# patent applications, trade secret, or copyright. Dissemination of
# this information or reproduction of this material is strictly
# forbidden unless prior written permission is obtained from Insipher.
#

ISTIO_VERSION=1.6.0
ROOT_PATH=$PWD

mkdir -p $ROOT_PATH/istio/dist

cd $ROOT_PATH/istio/dist

curl -L https://istio.io/downloadIstio | ISTIO_VERSION=$ISTIO_VERSION sh -

cd $ROOT_PATH

$ROOT_PATH/istio/dist/istio-$ISTIO_VERSION/bin/istioctl manifest apply -f $ROOT_PATH/istio/insipher-manifest.yaml

kubectl label namespace $INSIPHER_NAMESPACE istio-injection=enabled